'use strict'

class DashboardController {
}

module.exports = DashboardController
