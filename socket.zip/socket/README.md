# e-contactos
API REST en Express con postgresSQL
RUTAS DE LA API:

# AGENDAS

/api/agendas (GET, POST)
/api/agendas/:id (GET, PUT, DELETE)

# GRUPOS

/api/grupos (GET, POST)
/api/grupos/:id (GET, PUT, DELETE)

# CONTACTOS

/api/contactos (GET, POST)
/api/contactos/:id (GET, PUT, DELETE)

# IMAGENES

/api/imagenes/ (GET, POST)
/api/imagenes/:id (GET, PUT, DELETE)
