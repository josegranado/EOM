const express = require("express");
const socket = require("socket.io");
const cors = require('cors');
const bodyParser = require('body-parser')
// App setup
const PORT = 8000;
const app = express();
const server = app.listen(PORT, function () {
  console.log(`Listening on port ${PORT}`);
  console.log(`http://localhost:${PORT}`);
});

// Static files
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin','*');
    res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
    res.header('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
    next();
});
app.use(cors());
const io = require('socket.io')(server, {
    cors: {
        origin: '*'
    }
});
// Socket setup
const { Sequelize, Model, DataTypes } = require("sequelize");
const sequelize = new Sequelize('EOM', 'postgres', 'alfonzo97', {
    host: 'localhost',
    dialect: 'postgres'
  });
/* table.string('content').nullable();
      table.integer('twin_id').nullable();
      table.integer('from').nullable();
      table.integer('to').nullable();
      table.integer('state').nullable();
      table.integer('deleted').nullable();
 */
const Message = sequelize.define('messages', {
    content: DataTypes.TEXT,
    twin_id: DataTypes.INTEGER,
    from: DataTypes.INTEGER,
    to: DataTypes.INTEGER,
    state: DataTypes.INTEGER,
    deleted: DataTypes.INTEGER,
},{ timestamps: false })     
const Notification = sequelize.define('notifications', {
    type: DataTypes.INTEGER,
    from: DataTypes.INTEGER,
    to: DataTypes.INTEGER,
    state: DataTypes.INTEGER,
    deleted: DataTypes.INTEGER,
}, { timestamps: false })
io.on("connection", (socket) => {
    socket.on('view-notification', async (data) => {
        try{
            const id = data.id;
            await Notification.update({ state: 1 }, {
                where: {
                  to: id,
                  deleted: 0
                }
              });
            socket.emit('notification-event', [] );
            socket.broadcast.emit('notification-event', []);
        }catch(e){
            console.log(e)
        }
    });
    socket.on('view-message', async (data) => {
        try{
            const id = data.twin_id;
            const user_id = data.identity.id;
            await Message.update({ state: 1 }, {
                where: {
                  to: user_id,
                  deleted: 0
                }
              });
            socket.emit('message-event', [] );
            socket.broadcast.emit('message-event', []);
        }catch(e ){
            console.log( e )
        }

    });
    socket.on('send-notification', async (data) => {
        try{
           const notification = await Notification.create({
                from: data.from,
                to: data.to,
                state: 0,
                deleted: 0,
                type: data.type 
           })
            socket.emit('notification-event', []);
            socket.broadcast.emit('notification-event', []);
        }catch( e ){
            console.log( e )
        }
    });
    socket.on('send-message', async (data) => {
        try{
            /*
                const message = new Message();
            message.from = data.from;
            message.twin_id = data.twin_id
            message.content = data.content;
            message.deleted = 0;
            message.to = data.to;
            message.state = 0;
            */
            const message = await Message.create({
                from: data.from,
                twin_id: data.twin_id,
                content: data.content,
                deleted: 0,
                to: data.to,
                state: 0
            })
            socket.emit('message-event', []);
            socket.broadcast.emit('message-event', [] );
        }catch(e){
            console.log( e )
        }
    });
});
